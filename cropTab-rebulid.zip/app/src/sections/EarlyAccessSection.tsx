import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function EarlyAccessSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const verticalTextRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Vertical text letter-by-letter animation
      if (verticalTextRef.current) {
        const letters = verticalTextRef.current.querySelectorAll('.letter');
        gsap.fromTo(
          letters,
          { opacity: 0, y: 20 },
          {
            opacity: 1,
            y: 0,
            duration: 0.5,
            stagger: 0.03,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: verticalTextRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }

      // Content animation
      if (contentRef.current) {
        gsap.fromTo(
          contentRef.current.children,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.12,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: contentRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const verticalTitle = "You don't get many chances to be early";

  return (
    <section
      ref={sectionRef}
      className="relative w-full py-24 lg:py-32 bg-[#3d4718]"
    >
      <div className="section-container">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8">
          {/* Left - Vertical Text */}
          <div className="lg:col-span-6">
            <div
              ref={verticalTextRef}
              className="vertical-text text-[clamp(1.25rem,2.5vw,2rem)] font-light text-[#f5f5f5] tracking-wide"
            >
              {verticalTitle.split('').map((char, index) => (
                <span
                  key={index}
                  className="letter inline-block"
                  style={{ display: char === ' ' ? 'inline' : 'inline-block' }}
                >
                  {char === ' ' ? '\u00A0' : char}
                </span>
              ))}
            </div>
          </div>

          {/* Right - Content */}
          <div ref={contentRef} className="lg:col-span-6 lg:pt-8">
            <h3 className="text-xl lg:text-2xl font-light text-[#f5f5f5] mb-6">
              To lead, not follow
            </h3>

            <p className="text-lg text-[#f5f5f5]/80 leading-relaxed">
              To shape what farming becomes — not just adapt to it. CropTab™ is 
              already in the hands of progressive growers rewriting the rules. 
              If you're ready, we'll make room for you.
            </p>

            <div className="mt-10 flex flex-col sm:flex-row gap-4">
              <button className="btn-primary">
                <span className="w-1 h-1 rounded-full bg-[#f5f5f5]" />
                Request a Sample
                <span className="w-1 h-1 rounded-full bg-[#f5f5f5]" />
              </button>
              <button className="btn-primary">
                <span className="w-1 h-1 rounded-full bg-[#f5f5f5]" />
                Talk to Our Team
                <span className="w-1 h-1 rounded-full bg-[#f5f5f5]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
