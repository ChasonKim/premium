import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function DeliverySection() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      if (titleRef.current) {
        gsap.fromTo(
          titleRef.current,
          { y: 60, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: titleRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }

      // Content animation
      if (contentRef.current) {
        gsap.fromTo(
          contentRef.current,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: contentRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full py-24 lg:py-32 bg-[#3d4718]"
    >
      <div className="section-container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Left - Title */}
          <div>
            <h2
              ref={titleRef}
              className="text-[clamp(2rem,5vw,4rem)] font-light text-[#f5f5f5] leading-[1.1] tracking-[-0.02em]"
            >
              Reinventing<br />
              delivery
            </h2>
          </div>

          {/* Right - Content */}
          <div ref={contentRef} className="lg:pt-4">
            <p className="text-lg lg:text-xl text-[#f5f5f5]/80 leading-relaxed">
              <strong className="text-[#f5f5f5]">1,000 tablets</strong> (2,500 acres) - 
              just <strong className="text-[#f5f5f5]">29 lb / 13 kg</strong>. Fits in a 
              courier box. Ships with FedEx, DHL, even Amazon. Thousands of acres, 
              delivered overnight.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
