import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Package, Cloud, Droplets } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const stats = [
  {
    icon: Package,
    value: '1000',
    suffix: 'x',
    title: 'lighter logistics',
    description:
      'One 13 kg box replaces 25 tons of fertilizer — courier-shippable, pallet-free.',
  },
  {
    icon: Cloud,
    value: '½',
    suffix: '',
    title: 'ton of CO₂e saved per acre',
    description:
      'Life-cycle analysis shows ~500–600 lb CO₂e savings per acre.',
  },
  {
    icon: Droplets,
    value: '99',
    suffix: '%',
    title: 'uptake path',
    description:
      'Every gram applied is absorbed — no leaching, no volatilization.',
  },
];

export default function StatsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (cardsRef.current) {
        const cards = cardsRef.current.querySelectorAll('.stat-card');
        
        cards.forEach((card, index) => {
          const valueEl = card.querySelector('.stat-value');
          const statData = stats[index];
          
          gsap.fromTo(
            card,
            { y: 60, opacity: 0 },
            {
              y: 0,
              opacity: 1,
              duration: 0.8,
              ease: 'power3.out',
              scrollTrigger: {
                trigger: card,
                start: 'top 85%',
                toggleActions: 'play none none reverse',
                onEnter: () => {
                  if (valueEl && statData.value !== '½') {
                    gsap.fromTo(
                      { val: 0 },
                      { val: parseInt(statData.value) },
                      {
                        duration: 2,
                        ease: 'power2.out',
                        onUpdate: function () {
                          if (valueEl) {
                            valueEl.textContent = Math.round(this.targets()[0].val).toString();
                          }
                        },
                      }
                    );
                  }
                },
              },
            }
          );
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="stats"
      className="relative w-full py-24 lg:py-32 bg-[#2d3518]"
    >
      <div className="section-container">
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12"
        >
          {stats.map((stat, index) => (
            <div
              key={index}
              className="stat-card group relative p-6 lg:p-8"
            >
              {/* Icon */}
              <div className="w-10 h-10 rounded-full bg-[#f5f5f5]/10 flex items-center justify-center mb-6">
                <stat.icon className="w-4 h-4 text-[#f5f5f5]" />
              </div>

              {/* Value */}
              <div className="flex items-baseline gap-1 mb-3">
                <span className="stat-value text-[clamp(3rem,6vw,4rem)] font-light text-[#f5f5f5] leading-none tracking-[-0.02em]">
                  {stat.value === '½' ? '½' : '0'}
                </span>
                {stat.suffix && (
                  <span className="text-[clamp(1.5rem,3vw,2rem)] font-light text-[#f5f5f5]">
                    {stat.suffix}
                  </span>
                )}
              </div>

              {/* Title */}
              <h3 className="text-lg lg:text-xl font-light text-[#f5f5f5] mb-4">
                {stat.title}
              </h3>

              {/* Description */}
              <p className="text-sm text-[#f5f5f5]/60 leading-relaxed">
                {stat.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
