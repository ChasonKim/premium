import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function CTASection() {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Parallax background effect
      if (imageRef.current && sectionRef.current) {
        gsap.to(imageRef.current, {
          yPercent: 15,
          ease: 'none',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top bottom',
            end: 'bottom top',
            scrub: 1,
          },
        });
      }

      // Content animation
      if (contentRef.current) {
        gsap.fromTo(
          contentRef.current.children,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.15,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: contentRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="cta"
      className="relative w-full min-h-[70vh] overflow-hidden"
    >
      {/* Background Image with Parallax */}
      <div
        ref={imageRef}
        className="absolute inset-0 w-full h-[120%] -top-[10%]"
      >
        <img
          src="/images/plant-seedling.jpg"
          alt="Plant seedling growing"
          className="w-full h-full object-cover"
        />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-[#2d3518]/70" />
      </div>

      {/* Content */}
      <div className="relative z-10 section-container py-24 lg:py-32">
        <div className="max-w-2xl mx-auto text-center">
          <div ref={contentRef}>
            <p className="text-sm tracking-[0.15em] uppercase text-[#f5f5f5]/60">
              Add more water
            </p>
            <p className="mt-2 text-[#f5f5f5]/70">
              It seems that a plant needs a little help.
            </p>

            <h2 className="mt-10 text-[clamp(2rem,5vw,4rem)] font-light text-[#f5f5f5] leading-tight tracking-[-0.02em]">
              Formats & Access
            </h2>

            <p className="mt-6 text-lg text-[#f5f5f5]/80 leading-relaxed">
              We're limiting early access to select growers and agronomy partners.
            </p>

            <button className="mt-10 inline-flex items-center gap-3 btn-primary group">
              <span>Request Access</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
