import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function ProblemSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const descRef = useRef<HTMLParagraphElement>(null);
  const statRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      if (titleRef.current) {
        gsap.fromTo(
          titleRef.current,
          { y: 60, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: titleRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }

      // Description animation
      if (descRef.current) {
        gsap.fromTo(
          descRef.current,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: descRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }

      // Stat counter animation
      if (statRef.current) {
        const statNumber = statRef.current.querySelector('.stat-number');
        if (statNumber) {
          gsap.fromTo(
            statRef.current,
            { y: 50, opacity: 0 },
            {
              y: 0,
              opacity: 1,
              duration: 0.8,
              ease: 'power3.out',
              scrollTrigger: {
                trigger: statRef.current,
                start: 'top 80%',
                toggleActions: 'play none none reverse',
                onEnter: () => {
                  gsap.fromTo(
                    { value: 0 },
                    { value: 70 },
                    {
                      duration: 2,
                      ease: 'power2.out',
                      onUpdate: function () {
                        if (statNumber) {
                          statNumber.textContent = Math.round(this.targets()[0].value).toString();
                        }
                      },
                    }
                  );
                },
              },
            }
          );
        }
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="problem"
      className="relative w-full py-24 lg:py-32 bg-gradient-to-b from-[#3d4718] to-[#2d3518]"
    >
      <div className="section-container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Left - Title */}
          <div>
            <h2
              ref={titleRef}
              className="text-[clamp(2rem,5vw,4rem)] font-light text-[#f5f5f5] leading-[1.1] tracking-[-0.02em]"
            >
              Most fertilizers<br />
              never make it<br />
              to your plants
            </h2>
          </div>

          {/* Right - Description */}
          <div className="lg:pt-4">
            <p
              ref={descRef}
              className="text-lg lg:text-xl text-[#f5f5f5]/80 leading-relaxed max-w-lg"
            >
              Most of what you apply never reaches your crops. It evaporates, 
              washes away, or gets locked in the soil — leaving you with lower 
              yields, more spraying, and higher costs.
            </p>
          </div>
        </div>

        {/* Stat highlight */}
        <div ref={statRef} className="mt-20 lg:mt-32">
          <div className="flex flex-col items-start">
            <span className="text-xs tracking-[0.15em] uppercase text-[#f5f5f5]/60 mb-4">
              The reality
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-[clamp(4rem,12vw,10rem)] font-light text-[#f5f5f5] leading-none tracking-[-0.03em]">
                <span className="stat-number">0</span>%
              </span>
            </div>
            <p className="mt-4 text-lg text-[#f5f5f5]/70 max-w-md">
              of nitrogen is lost before crops can use it
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
