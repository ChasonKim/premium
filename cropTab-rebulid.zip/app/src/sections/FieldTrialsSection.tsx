import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function FieldTrialsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const verticalTextRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Vertical text letter-by-letter animation
      if (verticalTextRef.current) {
        const letters = verticalTextRef.current.querySelectorAll('.letter');
        gsap.fromTo(
          letters,
          { opacity: 0, y: 20 },
          {
            opacity: 1,
            y: 0,
            duration: 0.5,
            stagger: 0.04,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: verticalTextRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }

      // Content animation
      if (contentRef.current) {
        gsap.fromTo(
          contentRef.current.children,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.12,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: contentRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const verticalTitle = "Field Trials in Progress";

  return (
    <section
      ref={sectionRef}
      id="trials"
      className="relative w-full py-24 lg:py-32 bg-gradient-to-b from-[#2d3518] to-[#3d4718]"
    >
      <div className="section-container">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8">
          {/* Left - Vertical Text */}
          <div className="lg:col-span-5">
            <div
              ref={verticalTextRef}
              className="vertical-text text-[clamp(1.5rem,3vw,2.5rem)] font-light text-[#f5f5f5] tracking-wide"
            >
              {verticalTitle.split('').map((char, index) => (
                <span
                  key={index}
                  className="letter inline-block"
                  style={{ display: char === ' ' ? 'inline' : 'inline-block' }}
                >
                  {char === ' ' ? '\u00A0' : char}
                </span>
              ))}
            </div>
          </div>

          {/* Right - Content */}
          <div ref={contentRef} className="lg:col-span-7 lg:pt-4">
            <p className="text-lg lg:text-xl text-[#f5f5f5]/90 leading-relaxed max-w-xl">
              Our technology is in the field today, across multiple continents. 
              The goal — a single fertilizer platform farmers can trust, anywhere 
              in the world.
            </p>

            <div className="mt-10 p-6 lg:p-8 rounded-xl bg-[#f5f5f5]/5 border border-[#f5f5f5]/10">
              <span className="text-xs tracking-[0.15em] uppercase text-[#f5f5f5]/50">
                Coming Soon
              </span>
              <p className="mt-3 text-xl lg:text-2xl text-[#f5f5f5] font-light">
                October 2025 — full-season biomass and ROI data.
              </p>
            </div>

            <div className="mt-8">
              <p className="text-sm text-[#f5f5f5]/60">
                <strong className="text-[#f5f5f5]">Real data beats marketing claims.</strong><br />
                Follow the results as they come in.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
