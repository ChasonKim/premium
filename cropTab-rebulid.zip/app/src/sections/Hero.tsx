import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const productRef = useRef<HTMLDivElement>(null);
  const subtitleRef = useRef<HTMLDivElement>(null);
  const taglineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      if (titleRef.current) {
        gsap.fromTo(
          titleRef.current,
          { y: 80, opacity: 0 },
          { y: 0, opacity: 1, duration: 1.2, ease: 'power3.out', delay: 0.3 }
        );
      }

      // Product animation
      if (productRef.current) {
        gsap.fromTo(
          productRef.current,
          { scale: 0.7, opacity: 0 },
          { scale: 1, opacity: 1, duration: 1.4, ease: 'power3.out', delay: 0.5 }
        );

        // Floating animation
        gsap.to(productRef.current, {
          y: -15,
          duration: 3,
          ease: 'sine.inOut',
          repeat: -1,
          yoyo: true,
        });
      }

      // Subtitle animation
      if (subtitleRef.current) {
        gsap.fromTo(
          subtitleRef.current.children,
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', stagger: 0.15, delay: 0.8 }
        );
      }

      // Tagline animation
      if (taglineRef.current) {
        gsap.fromTo(
          taglineRef.current.children,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', stagger: 0.1, delay: 1.2 }
        );
      }

      // Scroll-triggered product rotation effect
      if (productRef.current && sectionRef.current) {
        ScrollTrigger.create({
          trigger: sectionRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: 1,
          onUpdate: (self) => {
            if (productRef.current) {
              gsap.to(productRef.current, {
                rotation: self.progress * 15,
                duration: 0.3,
                ease: 'power1.out',
              });
            }
          },
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="relative min-h-screen w-full bg-gradient-to-b from-[#2d3518] to-[#3d4718] overflow-hidden"
    >
      {/* Background gradient overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(255,255,255,0.03)_0%,_transparent_70%)]" />

      <div className="relative z-10 section-container min-h-screen flex flex-col">
        {/* Top section with title and CTA */}
        <div className="pt-24 lg:pt-28 flex items-start justify-between">
          <h1
            ref={titleRef}
            className="text-[clamp(3rem,10vw,8rem)] font-light tracking-[-0.02em] text-[#f5f5f5] leading-[0.9]"
          >
            CropTab<sup className="text-[0.3em] align-super">™</sup>
          </h1>

          <button
            onClick={() => scrollToSection('cta')}
            className="hidden md:flex items-center gap-2 mt-4 btn-primary"
          >
            <span className="w-1 h-1 rounded-full bg-[#f5f5f5]" />
            Request Access
            <span className="w-1 h-1 rounded-full bg-[#f5f5f5]" />
          </button>
        </div>

        {/* Middle info bar */}
        <div
          ref={subtitleRef}
          className="flex flex-col md:flex-row justify-between items-start md:items-center mt-6 pb-8 border-b border-[#f5f5f5]/20"
        >
          <span className="text-xs tracking-[0.15em] uppercase text-[#f5f5f5]/80">
            Fertilizer, Reinvented.
          </span>
          <span className="text-xs tracking-[0.15em] uppercase text-[#f5f5f5]/80 mt-2 md:mt-0 text-right">
            100 KG OF FERTILIZER —<br className="md:hidden" /> REIMAGINED AS A 13 G TABLET.
          </span>
        </div>

        {/* Product display area */}
        <div className="flex-1 flex items-center justify-center py-8 lg:py-12">
          <div
            ref={productRef}
            className="relative w-[280px] h-[280px] sm:w-[350px] sm:h-[350px] lg:w-[450px] lg:h-[450px]"
          >
            <img
              src="/images/croptab-product.png"
              alt="CropTab - Highly Efficient Fertilizer Tablet"
              className="w-full h-full object-contain drop-shadow-2xl"
            />
            {/* Glow effect */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(255,255,255,0.1)_0%,_transparent_60%)] blur-2xl" />
          </div>
        </div>

        {/* Bottom tagline */}
        <div ref={taglineRef} className="pb-8 lg:pb-12">
          <h2 className="text-[clamp(1.5rem,4vw,3rem)] font-light text-[#f5f5f5] leading-tight tracking-[-0.01em]">
            For Your Crops.<br />
            For the Planet.
          </h2>
          <p className="mt-4 text-xs tracking-[0.1em] uppercase text-[#f5f5f5]/70 max-w-md">
            Carbon-capsule technology that delivers nutrients with zero waste and zero emissions.
          </p>
        </div>
      </div>
    </section>
  );
}
