import { useEffect, useState, useRef } from 'react';
import { Menu, X, Leaf } from 'lucide-react';
import gsap from 'gsap';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (navRef.current) {
      gsap.fromTo(
        navRef.current,
        { y: -20, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', delay: 0.2 }
      );
    }
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <>
      <nav
        ref={navRef}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#2d3518]/90 backdrop-blur-md'
            : 'bg-transparent'
        }`}
      >
        <div className="section-container">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Left - Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="flex items-center gap-2 text-[#f5f5f5] hover:opacity-70 transition-opacity"
            >
              {isMenuOpen ? <X size={18} /> : <Menu size={18} />}
              <span className="text-xs tracking-[0.15em] uppercase font-medium">
                {isMenuOpen ? 'Close' : 'Menu'}
              </span>
            </button>

            {/* Center - Logo */}
            <div className="absolute left-1/2 transform -translate-x-1/2 flex items-center gap-2">
              <Leaf className="w-5 h-5 text-[#f5f5f5]" />
              <span className="text-sm tracking-[0.1em] font-medium">Farm Minerals</span>
            </div>

            {/* Right - Contact */}
            <button
              onClick={() => scrollToSection('footer')}
              className="text-xs tracking-[0.15em] uppercase font-medium text-[#f5f5f5] hover:opacity-70 transition-opacity"
            >
              Contact Us
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <div
        className={`fixed inset-0 z-40 bg-[#2d3518]/98 backdrop-blur-lg transition-all duration-500 ${
          isMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        <div className="flex flex-col items-center justify-center h-full gap-8">
          {[
            { label: 'Home', id: 'hero' },
            { label: 'The Problem', id: 'problem' },
            { label: 'Our Solution', id: 'solution' },
            { label: 'Features', id: 'features' },
            { label: 'Impact', id: 'stats' },
            { label: 'Field Trials', id: 'trials' },
            { label: 'Request Access', id: 'cta' },
          ].map((item, index) => (
            <button
              key={item.id}
              onClick={() => scrollToSection(item.id)}
              className="text-2xl md:text-3xl font-light text-[#f5f5f5] hover:opacity-70 transition-opacity"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </>
  );
}
