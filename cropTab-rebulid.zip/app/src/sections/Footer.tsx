import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Linkedin, Mail, Leaf } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const footerLinks = {
  products: [
    { label: 'Macronutrient Fertilizers', href: '#' },
    { label: 'Micronutrient Fertilizers', href: '#' },
    { label: 'Feed Additives', href: '#' },
  ],
  science: [
    { label: 'CropTab™ NPK', href: '#' },
    { label: 'Nutripeak™ Micros', href: '#' },
    { label: 'ElevateFeed™', href: '#' },
    { label: 'Food Safety', href: '#' },
  ],
  about: [
    { label: 'Approach', href: '#' },
    { label: 'Sustainability', href: '#' },
  ],
};

export default function Footer() {
  const footerRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (contentRef.current) {
        gsap.fromTo(
          contentRef.current.children,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: contentRef.current,
              start: 'top 90%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, footerRef);

    return () => ctx.revert();
  }, []);

  return (
    <footer
      ref={footerRef}
      id="footer"
      className="relative w-full py-16 lg:py-24 bg-[#1a2010]"
    >
      <div className="section-container">
        <div ref={contentRef}>
          {/* Main Footer Content */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 lg:gap-12">
            {/* Products */}
            <div className="col-span-1">
              <h4 className="text-xs tracking-[0.15em] uppercase text-[#f5f5f5]/50 mb-4">
                Products
              </h4>
              <ul className="space-y-3">
                {footerLinks.products.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-sm text-[#f5f5f5]/70 hover:text-[#f5f5f5] transition-colors"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Science */}
            <div className="col-span-1">
              <h4 className="text-xs tracking-[0.15em] uppercase text-[#f5f5f5]/50 mb-4">
                Science
              </h4>
              <ul className="space-y-3">
                {footerLinks.science.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-sm text-[#f5f5f5]/70 hover:text-[#f5f5f5] transition-colors"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* About */}
            <div className="col-span-1">
              <h4 className="text-xs tracking-[0.15em] uppercase text-[#f5f5f5]/50 mb-4">
                About
              </h4>
              <ul className="space-y-3">
                {footerLinks.about.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-sm text-[#f5f5f5]/70 hover:text-[#f5f5f5] transition-colors"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div className="col-span-2 md:col-span-1 lg:col-span-3">
              <h4 className="text-xs tracking-[0.15em] uppercase text-[#f5f5f5]/50 mb-4">
                Contact
              </h4>
              <p className="text-sm text-[#f5f5f5]/70 mb-4">
                If you have any questions feel free to contact us:
              </p>
              <a
                href="mailto:hello@farmminerals.com"
                className="inline-flex items-center gap-2 text-sm text-[#f5f5f5] hover:opacity-70 transition-opacity"
              >
                <Mail className="w-4 h-4" />
                HELLO@FARMMINERALS.COM
              </a>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="mt-16 pt-8 border-t border-[#f5f5f5]/10">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              {/* Logo */}
              <div className="flex items-center gap-2">
                <Leaf className="w-4 h-4 text-[#f5f5f5]/50" />
                <span className="text-xs text-[#f5f5f5]/50 tracking-[0.1em]">
                  FARM MINERALS
                </span>
              </div>

              {/* Copyright */}
              <p className="text-xs text-[#f5f5f5]/40">
                © 2025. FARM MINERALS INC.
              </p>

              {/* Links */}
              <div className="flex items-center gap-6">
                <a
                  href="#"
                  className="text-xs text-[#f5f5f5]/50 hover:text-[#f5f5f5] transition-colors"
                >
                  Terms of Use
                </a>
                <a
                  href="https://www.linkedin.com/company/farm-minerals/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-[#f5f5f5]/50 hover:text-[#f5f5f5] transition-colors flex items-center gap-1"
                >
                  <Linkedin className="w-3 h-3" />
                  LinkedIn
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
