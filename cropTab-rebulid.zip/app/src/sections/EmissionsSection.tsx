import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function EmissionsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const verticalTextRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Vertical text letter-by-letter animation
      if (verticalTextRef.current) {
        const letters = verticalTextRef.current.querySelectorAll('.letter');
        gsap.fromTo(
          letters,
          { opacity: 0, y: 20 },
          {
            opacity: 1,
            y: 0,
            duration: 0.5,
            stagger: 0.05,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: verticalTextRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }

      // Content animation
      if (contentRef.current) {
        gsap.fromTo(
          contentRef.current.children,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: contentRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const verticalTitle = "Zero emissions";

  return (
    <section
      ref={sectionRef}
      className="relative w-full py-24 lg:py-32 bg-gradient-to-b from-[#3d4718] to-[#2d3518]"
    >
      <div className="section-container">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8">
          {/* Left - Vertical Text */}
          <div className="lg:col-span-5">
            <div
              ref={verticalTextRef}
              className="vertical-text text-[clamp(2rem,4vw,3.5rem)] font-light text-[#f5f5f5] tracking-wide"
            >
              {verticalTitle.split('').map((char, index) => (
                <span
                  key={index}
                  className="letter inline-block"
                  style={{ display: char === ' ' ? 'inline' : 'inline-block' }}
                >
                  {char === ' ' ? '\u00A0' : char}
                </span>
              ))}
            </div>
          </div>

          {/* Right - Content */}
          <div ref={contentRef} className="lg:col-span-7 lg:pt-8">
            <p className="text-lg lg:text-xl text-[#f5f5f5]/80 leading-relaxed max-w-xl">
              We skip energy-intensive processes entirely, cutting CO₂ at the source. 
              Cleaner to make, better for the planet
            </p>

            <p className="mt-8 text-xs text-[#f5f5f5]/50 max-w-lg leading-relaxed">
              *Equal to or better than the ROI published for leading NPK programs; 
              based on side-by-side trial economics and lower freight + zero-emission 
              practices.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
