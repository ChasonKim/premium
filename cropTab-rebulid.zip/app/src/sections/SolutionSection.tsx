import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function SolutionSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const verticalTextRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Vertical text letter-by-letter animation
      if (verticalTextRef.current) {
        const letters = verticalTextRef.current.querySelectorAll('.letter');
        gsap.fromTo(
          letters,
          { opacity: 0, y: 20 },
          {
            opacity: 1,
            y: 0,
            duration: 0.5,
            stagger: 0.05,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: verticalTextRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }

      // Content animation
      if (contentRef.current) {
        gsap.fromTo(
          contentRef.current.children,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.15,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: contentRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const verticalTitle = "How we found a better way";

  return (
    <section
      ref={sectionRef}
      id="solution"
      className="relative w-full py-24 lg:py-32 bg-[#2d3518]"
    >
      <div className="section-container">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8">
          {/* Left - Vertical Text */}
          <div className="lg:col-span-4">
            <div
              ref={verticalTextRef}
              className="vertical-text text-[clamp(1.5rem,3vw,2.5rem)] font-light text-[#f5f5f5] tracking-wide h-full"
            >
              {verticalTitle.split('').map((char, index) => (
                <span
                  key={index}
                  className="letter inline-block"
                  style={{ display: char === ' ' ? 'inline' : 'inline-block' }}
                >
                  {char === ' ' ? '\u00A0' : char}
                </span>
              ))}
            </div>
          </div>

          {/* Right - Content */}
          <div ref={contentRef} className="lg:col-span-8 lg:pl-12">
            <p className="text-xl lg:text-2xl text-[#f5f5f5]/90 leading-relaxed max-w-2xl">
              Meet <strong className="text-[#f5f5f5]">CropTab™</strong>. Powered by precision-engineered 
              carbon capsules, it marks the first major innovation in fertilizers in over{' '}
              <span className="text-[#f5f5f5]">35 years</span>.
            </p>

            <button className="mt-8 flex items-center gap-3 group">
              <span className="text-sm tracking-[0.1em] uppercase text-[#f5f5f5]/70 group-hover:text-[#f5f5f5] transition-colors">
                Learn more
              </span>
              <div className="w-10 h-10 rounded-full border border-[#f5f5f5]/30 flex items-center justify-center group-hover:bg-[#f5f5f5]/10 group-hover:border-[#f5f5f5]/50 transition-all">
                <ArrowRight className="w-4 h-4 text-[#f5f5f5]" />
              </div>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
