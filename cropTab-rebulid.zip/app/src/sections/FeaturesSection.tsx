import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Microscope, Wrench, Leaf } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const features = [
  {
    icon: Microscope,
    title: 'Smaller than a plant cell',
    description:
      'Engineered to pass through the surface and deliver nutrients from within.',
  },
  {
    icon: Wrench,
    title: 'Effortlessly integrative',
    description:
      'No new tools. No learning curve. Just a smarter way to get the same job done — with less waste and zero emissions.',
  },
  {
    icon: Leaf,
    title: 'Zero manufacturing emissions',
    description:
      'We completely bypass the Haber-Bosch process — no CO₂, no NOₓ, zero compromise.',
  },
];

export default function FeaturesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (cardsRef.current) {
        const cards = cardsRef.current.querySelectorAll('.feature-card');
        gsap.fromTo(
          cards,
          { y: 60, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.2,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="features"
      className="relative w-full py-24 lg:py-32 bg-gradient-to-b from-[#2d3518] to-[#3d4718]"
    >
      <div className="section-container">
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8"
        >
          {features.map((feature, index) => (
            <div
              key={index}
              className="feature-card group relative p-8 lg:p-10 rounded-2xl bg-[#f5f5f5]/5 border border-[#f5f5f5]/10 hover:bg-[#f5f5f5]/10 hover:border-[#f5f5f5]/20 transition-all duration-500 hover:-translate-y-2"
            >
              {/* Icon */}
              <div className="w-12 h-12 rounded-full bg-[#f5f5f5]/10 flex items-center justify-center mb-6 group-hover:bg-[#f5f5f5]/20 transition-colors">
                <feature.icon className="w-5 h-5 text-[#f5f5f5]" />
              </div>

              {/* Title */}
              <h3 className="text-xl lg:text-2xl font-light text-[#f5f5f5] mb-4 leading-tight">
                {feature.title}
              </h3>

              {/* Description */}
              <p className="text-[#f5f5f5]/70 leading-relaxed text-sm lg:text-base">
                {feature.description}
              </p>

              {/* Hover glow */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#f5f5f5]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
