import { useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

import Navbar from './sections/Navbar';
import Hero from './sections/Hero';
import ProblemSection from './sections/ProblemSection';
import SolutionSection from './sections/SolutionSection';
import FeaturesSection from './sections/FeaturesSection';
import DeliverySection from './sections/DeliverySection';
import EmissionsSection from './sections/EmissionsSection';
import BetterPlantsSection from './sections/BetterPlantsSection';
import StatsSection from './sections/StatsSection';
import FieldTrialsSection from './sections/FieldTrialsSection';
import CTASection from './sections/CTASection';
import EarlyAccessSection from './sections/EarlyAccessSection';
import Footer from './sections/Footer';

// Register GSAP plugins
gsap.registerPlugin(ScrollTrigger);

function App() {
  useEffect(() => {
    // Configure ScrollTrigger defaults
    ScrollTrigger.defaults({
      toggleActions: 'play none none reverse',
    });

    // Refresh ScrollTrigger on load
    ScrollTrigger.refresh();

    // Cleanup on unmount
    return () => {
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill());
    };
  }, []);

  return (
    <div className="relative w-full min-h-screen bg-[#2d3518]">
      <Navbar />
      <main>
        <Hero />
        <ProblemSection />
        <SolutionSection />
        <FeaturesSection />
        <DeliverySection />
        <EmissionsSection />
        <BetterPlantsSection />
        <StatsSection />
        <FieldTrialsSection />
        <CTASection />
        <EarlyAccessSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;
