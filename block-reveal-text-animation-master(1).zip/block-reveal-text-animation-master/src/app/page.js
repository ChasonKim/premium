import Copy from '@/components/Copy';
import { ReactLenis } from "lenis/react"

export default function Home() {
  return (
    <>
      <ReactLenis root />

      <nav>
        <p>Static House</p>
        <p>Menu</p>
      </nav>

      <section className="intro">
        <div className="section-bg">
          <img src="/img_1.jpg" alt="" />
        </div>

        <Copy>
          <h1>
            Framed in tungsten and shadows, every shot holds its own deliberate
            tension.
          </h1>
        </Copy>
      </section>

      <section className="about">
        <Copy>
          <p>
            This is cinematography in its raw form with practical lamps, soft
            falloff, and the presence of grain that fills each corner of the
            frame.Every oom functions as a set andevery posture becomes a
            composition.Light moves acrss funitureand faceg,shaping scenes
            with a natural sense of depth
          </p>
        </Copy>
      </section>

      <section className="banner-img">
        <div className="section-bg">
          <img src="/img_2.jpg" alt="" />
        </div>
      </section>

      <section className="services">
        <Copy>
          <h1>
            Still frames with bold contrast and lighting choices that embraceimper
            fection.
          </h1>
        </Copy>
      </section>

      <section className="banner-img">
        <div className="section-bg">
          <img src="/img_3.jpg" alt="" />
        </div>
      </section>

      <section className="cta">
        <Copy>
          <p>
            the camera settles into long takes and patient movement. Colors stay
            unrefined and shadows turn into textureThe image waits for action
            instead of chasing it,Every frame fomsa clear visual language built
            through restraint
          </p>
        </Copy>
      </section>

      <section className="outro">
        <div className="section-bg">
          <img src="/img_4.jpg" alt="" />
        </div>

        <Copy>
          <h1>
            Cinematography thrives in the details from the grain to the falloff to
            the glow.
          </h1>
        </Copy>
      </section>
    </>
  );
}
