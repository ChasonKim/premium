import React from 'react'

const page = () => {
  return (
    <>
      <section className='h-screen w-full flex items-center justify-center'>
        <h1 className='text-[6vw] text-white capitalize leading-none tracking-tight font-medium text-center'>
          Unique Full screen <br /> navigation
        </h1>
      </section>
    </>
  )
}

export default page